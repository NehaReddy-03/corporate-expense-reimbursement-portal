"""
Audit Trail Service
"""
from typing import List, Dict, Any
from fastapi import HTTPException, status
from app.repositories.audit_repository import AuditRepository
from app.repositories.claim_repository import ClaimRepository

class AuditService:
    @staticmethod
    def get_claim_audit_logs(claim_id: int, user: dict) -> List[Dict[str, Any]]:
        claim = ClaimRepository.get_by_id(claim_id)
        if not claim:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Claim #{claim_id} not found.")

        # RBAC Check: Employees can only view audit trail of their own claims
        if user["role"] == "EMPLOYEE" and claim["user_id"] != user["id"]:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Unauthorized: You cannot view audit logs for claims submitted by another user."
            )

        return AuditRepository.get_by_claim_id(claim_id)

    @staticmethod
    def get_enterprise_audit_logs(user: dict, limit: int = 100) -> List[Dict[str, Any]]:
        if user["role"] == "EMPLOYEE":
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Unauthorized: Enterprise-wide audit log inspection is restricted to Manager and Finance roles."
            )
        return AuditRepository.list_all(limit=limit)
