"""
Authentication Service
Handles user verification, password hashing, and token generation.
"""
import hashlib
from typing import Optional, Dict, Any, List
from fastapi import HTTPException, status
from app.repositories.user_repository import UserRepository
from app.middleware.auth_middleware import create_access_token

def hash_password(password: str) -> str:
    """Generates SHA-256 hash with a domain salt for password storage."""
    salt = "enterprise_bea_salt_2026"
    return hashlib.sha256(f"{salt}:{password}".encode("utf-8")).hexdigest()

def verify_password(plain_password: str, password_hash: str) -> bool:
    """Verifies a plain password against stored hash."""
    return hash_password(plain_password) == password_hash

class AuthService:
    @staticmethod
    def authenticate_user(email: str, password: str) -> Dict[str, Any]:
        """Authenticates user credentials and issues a signed token."""
        user = UserRepository.get_by_email(email)
        if not user or not verify_password(password, user["password_hash"]):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid credentials. Check email and password.",
            )
        
        token = create_access_token(user["id"], user["email"], user["role"])
        return {
            "access_token": token,
            "token_type": "bearer",
            "user": {
                "id": user["id"],
                "name": user["name"],
                "email": user["email"],
                "role": user["role"],
                "created_at": user.get("created_at"),
            }
        }

    @staticmethod
    def register_user(name: str, email: str, password: str, role: str) -> Dict[str, Any]:
        """Registers a new corporate user, hashing their password."""
        existing = UserRepository.get_by_email(email)
        if existing:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=f"User with email '{email}' already exists."
            )
        pw_hash = hash_password(password)
        created = UserRepository.create(name=name, email=email, password_hash=pw_hash, role=role)
        return created

    @staticmethod
    def get_all_users() -> List[Dict[str, Any]]:
        """Returns all registered users for demo switcher and management."""
        return UserRepository.list_all()

    @staticmethod
    def get_user_by_id(user_id: int) -> Optional[Dict[str, Any]]:
        return UserRepository.get_by_id(user_id)
