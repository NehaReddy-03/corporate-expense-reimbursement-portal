"""
Expense Claim Service - Business Rules Engine & State Machine
Enforces:
1. RBAC permissions
2. Claim State Machine (PENDING -> APPROVED/REJECTED -> SETTLED)
3. Manager Approval Threshold (amount <= 10,000 for MANAGER, > 10,000 requires FINANCE)
4. Duplicate Detection Engine (alerts on same user, category, and amount within 48h)
5. Mandatory comments for claim rejection
6. Immutable audit trail logging on every state change
"""
from typing import List, Dict, Any, Optional
from fastapi import HTTPException, status
from app.config import MANAGER_APPROVAL_THRESHOLD, DUPLICATE_WINDOW_HOURS
from app.models.schemas import ClaimCreateRequest, ClaimStatus
from app.repositories.claim_repository import ClaimRepository
from app.repositories.audit_repository import AuditRepository

class ClaimService:
    @staticmethod
    def create_claim(user: dict, claim_in: ClaimCreateRequest) -> Dict[str, Any]:
        """
        Submits an expense claim with Duplicate Detection and creates an initial audit log.
        """
        # 1. Duplicate Detection Engine: Check if identical amount & category was submitted within 48h
        recent_duplicate = ClaimRepository.find_recent_duplicate(
            user_id=user["id"],
            category=claim_in.category.value,
            amount=claim_in.amount,
            window_hours=DUPLICATE_WINDOW_HOURS
        )
        has_duplicate = recent_duplicate is not None

        # 2. Persist Claim into Database
        created_claim = ClaimRepository.create(
            user_id=user["id"],
            category=claim_in.category.value,
            amount=claim_in.amount,
            description=claim_in.description.strip(),
            expense_date=str(claim_in.expense_date)
        )

        # 3. Create Audit Trail Entry
        audit_note = "Expense claim submitted by employee."
        if has_duplicate:
            audit_note += f" [DUPLICATE ALERT: Matching claim #{recent_duplicate['id']} submitted within {DUPLICATE_WINDOW_HOURS} hours]"

        AuditRepository.create(
            claim_id=created_claim["id"],
            performed_by=user["id"],
            action="CLAIM_CREATED",
            notes=audit_note
        )

        created_claim["is_duplicate_warning"] = has_duplicate
        created_claim["requires_finance_approval"] = created_claim["amount"] > MANAGER_APPROVAL_THRESHOLD
        return created_claim

    @staticmethod
    def list_claims_for_user(user: dict, status_filter: Optional[str] = None, user_id_override: Optional[int] = None) -> List[Dict[str, Any]]:
        """
        RBAC Listing:
        - If user_id_override is provided, returns claims for that specific user.
        - EMPLOYEE can only view their own claims.
        - MANAGER and FINANCE can view all enterprise claims by default.
        """
        if user_id_override is not None:
            claims = ClaimRepository.list_claims(user_id=user_id_override, status=status_filter)
        elif user["role"] == "EMPLOYEE":
            claims = ClaimRepository.list_claims(user_id=user["id"], status=status_filter)
        else:
            claims = ClaimRepository.list_claims(user_id=None, status=status_filter)

        # Augment with business flags
        for claim in claims:
            claim["requires_finance_approval"] = claim["amount"] > MANAGER_APPROVAL_THRESHOLD
            # Check duplicate status
            dup = ClaimRepository.find_recent_duplicate(
                user_id=claim["user_id"],
                category=claim["category"],
                amount=claim["amount"],
                window_hours=DUPLICATE_WINDOW_HOURS
            )
            # A duplicate warning applies if another claim matches
            claim["is_duplicate_warning"] = dup is not None and dup["id"] != claim["id"]

        return claims

    @staticmethod
    def get_claim_details(claim_id: int, user: dict) -> Dict[str, Any]:
        """Retrieves single claim with access control."""
        claim = ClaimRepository.get_by_id(claim_id)
        if not claim:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Claim #{claim_id} not found.")

        # RBAC Check: Employees can only view their own claims
        if user["role"] == "EMPLOYEE" and claim["user_id"] != user["id"]:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Unauthorized: You cannot access claims submitted by other employees."
            )

        claim["requires_finance_approval"] = claim["amount"] > MANAGER_APPROVAL_THRESHOLD
        dup = ClaimRepository.find_recent_duplicate(
            user_id=claim["user_id"],
            category=claim["category"],
            amount=claim["amount"],
            window_hours=DUPLICATE_WINDOW_HOURS
        )
        claim["is_duplicate_warning"] = dup is not None and dup["id"] != claim["id"]
        return claim

    @staticmethod
    def approve_claim(claim_id: int, user: dict, notes: Optional[str] = None) -> Dict[str, Any]:
        """
        Approves a claim enforcing:
        1. State Machine: Only PENDING claims can be APPROVED.
        2. Threshold Rule: If amount > 10,000, only FINANCE can approve.
        3. Immutable Audit Log.
        """
        claim = ClaimRepository.get_by_id(claim_id)
        if not claim:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Claim #{claim_id} not found.")

        # State Machine Transition Validation
        if claim["status"] != ClaimStatus.PENDING.value:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Invalid Transition: Cannot approve claim #{claim_id} with status '{claim['status']}'. Only PENDING claims can be approved."
            )

        # Threshold Rule: Manager limit is ₹10,000
        if user["role"] == "MANAGER" and claim["amount"] > MANAGER_APPROVAL_THRESHOLD:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Threshold Exceeded: Claim amount (₹{claim['amount']:,.2f}) exceeds the Manager approval limit of ₹{MANAGER_APPROVAL_THRESHOLD:,.2f}. Final approval must be processed by Finance."
            )

        # Transition State
        updated = ClaimRepository.update_status(claim_id, ClaimStatus.APPROVED.value)

        # Write Immutable Audit Log
        note_text = notes.strip() if notes else f"Claim approved by {user['role']} ({user['name']})."
        AuditRepository.create(
            claim_id=claim_id,
            performed_by=user["id"],
            action="CLAIM_APPROVED",
            notes=note_text
        )

        return updated

    @staticmethod
    def reject_claim(claim_id: int, user: dict, notes: Optional[str]) -> Dict[str, Any]:
        """
        Rejects a claim enforcing:
        1. State Machine: Only PENDING claims can be REJECTED.
        2. Business Rule: Rejection comments/notes are MANDATORY.
        3. Immutable Audit Log.
        """
        claim = ClaimRepository.get_by_id(claim_id)
        if not claim:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Claim #{claim_id} not found.")

        # State Machine Transition Validation
        if claim["status"] != ClaimStatus.PENDING.value:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Invalid Transition: Cannot reject claim #{claim_id} with status '{claim['status']}'. Only PENDING claims can be rejected."
            )

        # Mandatory Comment Rule
        if not notes or not notes.strip():
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail="Business Rule Violation: A mandatory rejection comment/reason must be provided when rejecting a claim."
            )

        # Transition State
        updated = ClaimRepository.update_status(claim_id, ClaimStatus.REJECTED.value)

        # Write Immutable Audit Log
        AuditRepository.create(
            claim_id=claim_id,
            performed_by=user["id"],
            action="CLAIM_REJECTED",
            notes=f"Rejection Reason: {notes.strip()}"
        )

        return updated

    @staticmethod
    def settle_single_claim(claim_id: int, user: dict, notes: Optional[str] = None) -> Dict[str, Any]:
        """
        Settles an approved claim. Only FINANCE can perform settlements.
        """
        if user["role"] != "FINANCE":
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access Denied: Only Finance personnel are authorized to settle reimbursement claims."
            )

        claim = ClaimRepository.get_by_id(claim_id)
        if not claim:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Claim #{claim_id} not found.")

        # State Machine Check
        if claim["status"] != ClaimStatus.APPROVED.value:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Invalid Transition: Cannot settle claim #{claim_id} with status '{claim['status']}'. Only APPROVED claims can be settled for reimbursement."
            )

        updated = ClaimRepository.update_status(claim_id, ClaimStatus.SETTLED.value)

        settle_note = notes.strip() if notes else f"Claim settled and disbursed by Finance ({user['name']})."
        AuditRepository.create(
            claim_id=claim_id,
            performed_by=user["id"],
            action="CLAIM_SETTLED",
            notes=settle_note
        )

        return updated

    @staticmethod
    def batch_settle_approved(user: dict) -> Dict[str, Any]:
        """
        Performs one-click batch settlement for all approved claims.
        Only FINANCE role can execute.
        """
        if user["role"] != "FINANCE":
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access Denied: Only Finance personnel can execute batch settlements."
            )

        settled_ids, total_amount = ClaimRepository.batch_settle_all_approved()

        # Record audit log for every settled claim
        for cid in settled_ids:
            AuditRepository.create(
                claim_id=cid,
                performed_by=user["id"],
                action="BATCH_SETTLEMENT",
                notes=f"Processed in batch settlement by Finance ({user['name']}). Total batch value: ₹{total_amount:,.2f}"
            )

        return {
            "settled_count": len(settled_ids),
            "total_amount": total_amount,
            "settled_claim_ids": settled_ids,
            "message": f"Successfully settled {len(settled_ids)} approved claims totaling ₹{total_amount:,.2f}."
        }

    @staticmethod
    def cancel_claim(claim_id: int, user: dict, notes: Optional[str] = None) -> Dict[str, Any]:
        """
        Allows an employee to withdraw/cancel their own PENDING claim.
        Managers and Finance can also cancel pending claims.
        """
        claim = ClaimRepository.get_by_id(claim_id)
        if not claim:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Claim #{claim_id} not found."
            )

        # Scoped permissions: Submitter or Manager/Finance
        if user["role"] == "EMPLOYEE" and claim["user_id"] != user["id"]:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access Denied: You can only withdraw your own claims."
            )

        if claim["status"] != ClaimStatus.PENDING.value:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Cannot cancel claim #{claim_id}: Only PENDING claims can be cancelled."
            )

        cancel_note = notes.strip() if (notes and notes.strip()) else f"Claim withdrawn by submitter ({user['name']})."
        updated = ClaimRepository.update_status(claim_id, ClaimStatus.REJECTED.value)

        AuditRepository.create(
            claim_id=claim_id,
            performed_by=user["id"],
            action="CLAIM_CANCELLED",
            notes=cancel_note
        )

        return updated

    @staticmethod
    def get_dashboard_metrics(user: dict, user_id_override: Optional[int] = None) -> Dict[str, Any]:
        if user_id_override is not None:
            user_id = user_id_override
        else:
            user_id = user["id"] if user["role"] == "EMPLOYEE" else None
        return ClaimRepository.get_metrics(user_id=user_id)
