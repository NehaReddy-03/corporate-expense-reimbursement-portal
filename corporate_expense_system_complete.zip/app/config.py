"""
Application Configuration
"""
from pathlib import Path

# Paths
BASE_DIR = Path(__file__).resolve().parent.parent
DB_PATH = BASE_DIR / "expense_portal.db"
STATIC_DIR = BASE_DIR / "static"

# Business Rules
MANAGER_APPROVAL_THRESHOLD = 10000.0  # ₹10,000 threshold
DUPLICATE_WINDOW_HOURS = 48           # 48-hour window for duplicate detection

# Security
SECRET_KEY = "enterprise-reimbursement-portal-secure-key-2026"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24  # 24 hours

# Server
HOST = "127.0.0.1"
PORT = 8000
