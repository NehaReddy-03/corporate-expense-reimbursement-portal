"""
Pydantic Schemas for Enterprise Data Transfer Objects (DTOs)
"""
from enum import Enum
from typing import Optional, List
from datetime import date, datetime
from pydantic import BaseModel, Field

class UserRole(str, Enum):
    EMPLOYEE = "EMPLOYEE"
    MANAGER = "MANAGER"
    FINANCE = "FINANCE"

class ClaimCategory(str, Enum):
    TRAVEL = "TRAVEL"
    MEALS = "MEALS"
    EQUIPMENT = "EQUIPMENT"
    OTHER = "OTHER"

class ClaimStatus(str, Enum):
    PENDING = "PENDING"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"
    SETTLED = "SETTLED"

# --- User Schemas ---
class UserLoginRequest(BaseModel):
    email: str = Field(..., description="Enterprise corporate email address")
    password: str

class UserRegisterRequest(BaseModel):
    name: str = Field(..., min_length=2, max_length=100, description="Full employee name")
    email: str = Field(..., description="Corporate email address")
    password: str = Field(..., min_length=6, description="Password (min 6 characters)")
    role: UserRole = Field(default=UserRole.EMPLOYEE, description="Corporate Role (EMPLOYEE, MANAGER, FINANCE)")

class UserResponse(BaseModel):
    id: int
    name: str
    email: str
    role: UserRole
    created_at: Optional[str] = None

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserResponse

# --- Claim Schemas ---
class ClaimCreateRequest(BaseModel):
    category: ClaimCategory
    amount: float = Field(..., gt=0, description="Amount must be strictly greater than 0")
    description: str = Field(..., min_length=3, max_length=500, description="Detailed explanation of the expense")
    expense_date: date = Field(..., description="Date when expense occurred (YYYY-MM-DD)")

class ClaimActionRequest(BaseModel):
    notes: Optional[str] = Field(None, description="Mandatory notes if rejecting a claim; optional for approvals")

class ClaimResponse(BaseModel):
    id: int
    user_id: int
    user_name: Optional[str] = None
    user_email: Optional[str] = None
    user_role: Optional[str] = None
    category: ClaimCategory
    amount: float
    description: str
    expense_date: str
    status: ClaimStatus
    created_at: str
    is_duplicate_warning: bool = False
    requires_finance_approval: bool = False

class BatchSettleResponse(BaseModel):
    settled_count: int
    total_amount: float
    settled_claim_ids: List[int]
    message: str

# --- Audit Log Schemas ---
class AuditLogResponse(BaseModel):
    id: int
    claim_id: int
    performed_by: int
    performer_name: Optional[str] = None
    performer_role: Optional[str] = None
    action: str
    notes: Optional[str] = None
    created_at: str

class MetricsResponse(BaseModel):
    total_claims: int
    total_amount: float
    pending_count: int
    pending_amount: float
    approved_count: int
    approved_amount: float
    settled_count: int
    settled_amount: float
    rejected_count: int
    rejected_amount: float
