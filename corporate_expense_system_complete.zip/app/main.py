"""
Enterprise Expense Claim & Reimbursement Portal - Main Application
Multi-tier Layered Architecture:
  - Controllers: HTTP handling, routing & validation
  - Services: Business logic, Threshold Engine, State Machine, Audit Service
  - Repositories: Data access with SQLite3
  - Middleware: Auth & Role-Based Access Control (RBAC)
"""
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, RedirectResponse

from app.config import STATIC_DIR
from app.repositories.database import init_db
from app.controllers.auth_controller import router as auth_router
from app.controllers.claim_controller import router as claim_router
from app.controllers.audit_controller import router as audit_router
from seed import seed_database

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: Initialize Database and Auto-seed if first run
    init_db()
    seed_database(force=False)
    yield
    # Shutdown logic if any

app = FastAPI(
    title="Corporate Expense Claim & Reimbursement Portal",
    description="""
    Enterprise Multi-tier Expense Portal for 4th-Year Building Enterprise Applications (BEA).
    
    ### Key Features:
    * **Role-Based Access Control (RBAC):** EMPLOYEE, MANAGER, FINANCE roles.
    * **State Machine:** PENDING -> APPROVED | REJECTED -> SETTLED.
    * **Enterprise Rules Engine:** 
      - ₹10,000 threshold limit for Manager approvals (high-value claims require Finance authorization).
      - 48-hour Duplicate Detection Engine.
      - Mandatory rejection reason enforcement.
    * **Immutable Audit Trail:** Persistent cryptographic log on all lifecycle actions.
    * **Finance Batch Actions:** One-click batch settlement.
    """,
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json",
    lifespan=lifespan
)

# CORS Middleware for local execution
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount Routers
app.include_router(auth_router)
app.include_router(claim_router)
app.include_router(audit_router)

# Mount Static Files (Frontend UI)
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")

@app.get("/api-docs", include_in_schema=False)
def redirect_api_docs():
    """Alias for Swagger OpenAPI interactive documentation."""
    return RedirectResponse(url="/docs")

@app.get("/presentation", include_in_schema=False)
def serve_presentation():
    """Serves the interactive web-based presentation deck."""
    return FileResponse(STATIC_DIR / "presentation.html")

@app.get("/download-pptx", include_in_schema=False)
def download_pptx():
    """Directly downloads the PowerPoint .pptx presentation deck."""
    pptx_path = STATIC_DIR.parent / "corporate_expense_portal_presentation.pptx"
    return FileResponse(
        pptx_path,
        media_type="application/vnd.openxmlformats-officedocument.presentationml.presentation",
        filename="corporate_expense_portal_presentation.pptx"
    )

@app.get("/download-pdf", include_in_schema=False)
def download_pdf():
    """Directly downloads the executive PDF Teammate & Viva Reference Guide."""
    pdf_path = STATIC_DIR.parent / "Corporate_Expense_System_Teammate_Guide.pdf"
    return FileResponse(
        pdf_path,
        media_type="application/pdf",
        filename="Corporate_Expense_System_Teammate_Guide.pdf"
    )

@app.get("/download-report-pdf", include_in_schema=False)
def download_report_pdf():
    """Directly downloads the official BMSIT CCA Phase-2 Course Project Report PDF."""
    pdf_path = STATIC_DIR.parent / "BMSIT_BCS703B_Course_Project_Report.pdf"
    return FileResponse(
        pdf_path,
        media_type="application/pdf",
        filename="BMSIT_BCS703B_Course_Project_Report.pdf"
    )

@app.get("/", include_in_schema=False)
def serve_dashboard():
    """Serves the single-page responsive enterprise dashboard."""
    index_file = STATIC_DIR / "index.html"
    return FileResponse(index_file)

@app.get("/health", tags=["System"])
def health_check():
    """System health verification endpoint."""
    return {"status": "HEALTHY", "tier": "Production-Enterprise", "version": "1.0.0"}
