"""
User Repository for Database Operations
"""
from typing import Optional, List, Dict, Any
from app.repositories.database import get_connection

class UserRepository:
    @staticmethod
    def get_by_id(user_id: int) -> Optional[Dict[str, Any]]:
        conn = get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT id, name, email, password_hash, role, created_at FROM Users WHERE id = ?;", (user_id,))
            row = cursor.fetchone()
            return dict(row) if row else None
        finally:
            conn.close()

    @staticmethod
    def get_by_email(email: str) -> Optional[Dict[str, Any]]:
        conn = get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT id, name, email, password_hash, role, created_at FROM Users WHERE LOWER(email) = LOWER(?);", (email.strip(),))
            row = cursor.fetchone()
            return dict(row) if row else None
        finally:
            conn.close()

    @staticmethod
    def list_all() -> List[Dict[str, Any]]:
        conn = get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT id, name, email, role, created_at FROM Users ORDER BY id ASC;")
            rows = cursor.fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    @staticmethod
    def create(name: str, email: str, password_hash: str, role: str) -> Dict[str, Any]:
        conn = get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO Users (name, email, password_hash, role) VALUES (?, ?, ?, ?);",
                (name, email.strip().lower(), password_hash, role)
            )
            user_id = cursor.lastrowid
            conn.commit()
            return UserRepository.get_by_id(user_id)
        finally:
            conn.close()
