"""
Expense Claim Repository for Database Operations
"""
from typing import Optional, List, Dict, Any, Tuple
from app.repositories.database import get_connection

class ClaimRepository:
    @staticmethod
    def create(user_id: int, category: str, amount: float, description: str, expense_date: str) -> Dict[str, Any]:
        conn = get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute(
                """
                INSERT INTO ExpenseClaims (user_id, category, amount, description, expense_date, status)
                VALUES (?, ?, ?, ?, ?, 'PENDING');
                """,
                (user_id, category, amount, description, expense_date)
            )
            claim_id = cursor.lastrowid
            conn.commit()
            return ClaimRepository.get_by_id(claim_id)
        finally:
            conn.close()

    @staticmethod
    def get_by_id(claim_id: int) -> Optional[Dict[str, Any]]:
        conn = get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute(
                """
                SELECT 
                    c.id, c.user_id, c.category, c.amount, c.description, 
                    c.expense_date, c.status, c.created_at,
                    u.name AS user_name, u.email AS user_email, u.role AS user_role
                FROM ExpenseClaims c
                JOIN Users u ON c.user_id = u.id
                WHERE c.id = ?;
                """,
                (claim_id,)
            )
            row = cursor.fetchone()
            return dict(row) if row else None
        finally:
            conn.close()

    @staticmethod
    def list_claims(user_id: Optional[int] = None, status: Optional[str] = None) -> List[Dict[str, Any]]:
        conn = get_connection()
        try:
            cursor = conn.cursor()
            query = """
                SELECT 
                    c.id, c.user_id, c.category, c.amount, c.description, 
                    c.expense_date, c.status, c.created_at,
                    u.name AS user_name, u.email AS user_email, u.role AS user_role
                FROM ExpenseClaims c
                JOIN Users u ON c.user_id = u.id
                WHERE 1=1
            """
            params = []
            if user_id is not None:
                query += " AND c.user_id = ?"
                params.append(user_id)
            if status is not None:
                query += " AND c.status = ?"
                params.append(status.upper())

            query += " ORDER BY c.created_at DESC, c.id DESC;"
            cursor.execute(query, tuple(params))
            rows = cursor.fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    @staticmethod
    def find_recent_duplicate(user_id: int, category: str, amount: float, window_hours: int = 48) -> Optional[Dict[str, Any]]:
        """
        Duplicate Detection Engine query:
        Checks for claims from the same user with the same category and same amount
        created within the specified window (48 hours).
        """
        conn = get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute(
                f"""
                SELECT id, user_id, category, amount, description, status, created_at
                FROM ExpenseClaims
                WHERE user_id = ?
                  AND category = ?
                  AND ABS(amount - ?) < 0.001
                  AND datetime(created_at) >= datetime('now', '-{window_hours} hours')
                ORDER BY created_at DESC
                LIMIT 1;
                """,
                (user_id, category, amount)
            )
            row = cursor.fetchone()
            return dict(row) if row else None
        finally:
            conn.close()

    @staticmethod
    def update_status(claim_id: int, new_status: str) -> Optional[Dict[str, Any]]:
        conn = get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE ExpenseClaims SET status = ? WHERE id = ?;",
                (new_status, claim_id)
            )
            conn.commit()
            return ClaimRepository.get_by_id(claim_id)
        finally:
            conn.close()

    @staticmethod
    def batch_settle_all_approved() -> Tuple[List[int], float]:
        """
        Atomically transitions all claims currently in APPROVED status to SETTLED.
        Returns a tuple of (list_of_settled_claim_ids, total_amount).
        """
        conn = get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("BEGIN TRANSACTION;")
            
            cursor.execute("SELECT id, amount FROM ExpenseClaims WHERE status = 'APPROVED';")
            rows = cursor.fetchall()
            if not rows:
                conn.commit()
                return [], 0.0

            claim_ids = [r["id"] for r in rows]
            total_amount = sum(float(r["amount"]) for r in rows)

            placeholders = ",".join("?" for _ in claim_ids)
            cursor.execute(
                f"UPDATE ExpenseClaims SET status = 'SETTLED' WHERE id IN ({placeholders});",
                tuple(claim_ids)
            )
            conn.commit()
            return claim_ids, total_amount
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    @staticmethod
    def get_metrics(user_id: Optional[int] = None) -> Dict[str, Any]:
        """Aggregates metrics for the executive dashboard."""
        conn = get_connection()
        try:
            cursor = conn.cursor()
            filter_clause = "WHERE user_id = ?" if user_id is not None else ""
            params = (user_id,) if user_id is not None else ()

            cursor.execute(f"""
                SELECT 
                    COUNT(*) as total_count,
                    COALESCE(SUM(amount), 0) as total_amount,
                    COALESCE(SUM(CASE WHEN status = 'PENDING' THEN 1 ELSE 0 END), 0) as pending_count,
                    COALESCE(SUM(CASE WHEN status = 'PENDING' THEN amount ELSE 0 END), 0) as pending_amount,
                    COALESCE(SUM(CASE WHEN status = 'APPROVED' THEN 1 ELSE 0 END), 0) as approved_count,
                    COALESCE(SUM(CASE WHEN status = 'APPROVED' THEN amount ELSE 0 END), 0) as approved_amount,
                    COALESCE(SUM(CASE WHEN status = 'SETTLED' THEN 1 ELSE 0 END), 0) as settled_count,
                    COALESCE(SUM(CASE WHEN status = 'SETTLED' THEN amount ELSE 0 END), 0) as settled_amount,
                    COALESCE(SUM(CASE WHEN status = 'REJECTED' THEN 1 ELSE 0 END), 0) as rejected_count,
                    COALESCE(SUM(CASE WHEN status = 'REJECTED' THEN amount ELSE 0 END), 0) as rejected_amount
                FROM ExpenseClaims {filter_clause};
            """, params)
            row = cursor.fetchone()
            return dict(row) if row else {}
        finally:
            conn.close()
