"""
Database Connection and Initialization using SQLite3
Zero-setup local execution with schema constraints and indexing
"""
import sqlite3
from typing import Generator
from app.config import DB_PATH

def get_connection() -> sqlite3.Connection:
    """Creates a connection with Row factory and Foreign Keys enabled."""
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn

def init_db() -> None:
    """Initializes the database schema matching enterprise requirements."""
    conn = get_connection()
    cursor = conn.cursor()

    # 1. Users Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS Users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL CHECK(role IN ('EMPLOYEE', 'MANAGER', 'FINANCE')),
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    """)

    # 2. ExpenseClaims Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS ExpenseClaims (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL REFERENCES Users(id) ON DELETE CASCADE,
        category TEXT NOT NULL CHECK(category IN ('TRAVEL', 'MEALS', 'EQUIPMENT', 'OTHER')),
        amount REAL NOT NULL CHECK(amount > 0),
        description TEXT NOT NULL,
        expense_date DATE NOT NULL,
        status TEXT NOT NULL DEFAULT 'PENDING' CHECK(status IN ('PENDING', 'APPROVED', 'REJECTED', 'SETTLED')),
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    """)

    # 3. AuditLogs Table (Immutable ledger)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS AuditLogs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        claim_id INTEGER NOT NULL REFERENCES ExpenseClaims(id) ON DELETE CASCADE,
        performed_by INTEGER NOT NULL REFERENCES Users(id) ON DELETE RESTRICT,
        action TEXT NOT NULL,
        notes TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    """)

    # Performance & Lookup Indexes
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_claims_user_id ON ExpenseClaims(user_id);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_claims_status ON ExpenseClaims(status);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_claims_created ON ExpenseClaims(created_at);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_audit_claim_id ON AuditLogs(claim_id);")

    conn.commit()
    conn.close()
