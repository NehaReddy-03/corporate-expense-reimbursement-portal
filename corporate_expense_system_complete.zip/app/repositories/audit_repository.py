"""
Audit Log Repository for Immutable Audit Trail
"""
from typing import List, Dict, Any, Optional
from app.repositories.database import get_connection

class AuditRepository:
    @staticmethod
    def create(claim_id: int, performed_by: int, action: str, notes: Optional[str] = None) -> Dict[str, Any]:
        """Writes an immutable record into the AuditLogs table."""
        conn = get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute(
                """
                INSERT INTO AuditLogs (claim_id, performed_by, action, notes)
                VALUES (?, ?, ?, ?);
                """,
                (claim_id, performed_by, action, notes)
            )
            audit_id = cursor.lastrowid
            conn.commit()

            cursor.execute(
                """
                SELECT 
                    a.id, a.claim_id, a.performed_by, a.action, a.notes, a.created_at,
                    u.name AS performer_name, u.role AS performer_role
                FROM AuditLogs a
                JOIN Users u ON a.performed_by = u.id
                WHERE a.id = ?;
                """,
                (audit_id,)
            )
            row = cursor.fetchone()
            return dict(row)
        finally:
            conn.close()

    @staticmethod
    def get_by_claim_id(claim_id: int) -> List[Dict[str, Any]]:
        """Retrieves chronological audit trail for a specific claim."""
        conn = get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute(
                """
                SELECT 
                    a.id, a.claim_id, a.performed_by, a.action, a.notes, a.created_at,
                    u.name AS performer_name, u.role AS performer_role
                FROM AuditLogs a
                JOIN Users u ON a.performed_by = u.id
                WHERE a.claim_id = ?
                ORDER BY a.created_at ASC, a.id ASC;
                """,
                (claim_id,)
            )
            rows = cursor.fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    @staticmethod
    def list_all(limit: int = 100) -> List[Dict[str, Any]]:
        """Retrieves enterprise-wide audit records ordered newest first."""
        conn = get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute(
                """
                SELECT 
                    a.id, a.claim_id, a.performed_by, a.action, a.notes, a.created_at,
                    u.name AS performer_name, u.role AS performer_role
                FROM AuditLogs a
                JOIN Users u ON a.performed_by = u.id
                ORDER BY a.created_at DESC, a.id DESC
                LIMIT ?;
                """,
                (limit,)
            )
            rows = cursor.fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()
