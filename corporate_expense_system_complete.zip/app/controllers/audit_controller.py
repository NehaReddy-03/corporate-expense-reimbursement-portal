"""
Enterprise Audit Log Controller
"""
from typing import List
from fastapi import APIRouter, Depends, Query
from app.models.schemas import AuditLogResponse
from app.services.audit_service import AuditService
from app.middleware.auth_middleware import require_roles

router = APIRouter(prefix="/api/audit-logs", tags=["Audit Trail"])

@router.get("", response_model=List[AuditLogResponse], summary="Inspect Enterprise Audit Log")
def get_all_audit_logs(
    limit: int = Query(100, ge=1, le=500),
    current_user: dict = Depends(require_roles("MANAGER", "FINANCE"))
):
    """
    Retrieves the global, immutable audit log across all corporate claims.
    Restricted to MANAGER and FINANCE roles.
    """
    return AuditService.get_enterprise_audit_logs(current_user, limit=limit)
