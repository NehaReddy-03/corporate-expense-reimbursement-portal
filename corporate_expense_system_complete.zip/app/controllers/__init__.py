from app.controllers.auth_controller import router as auth_router
from app.controllers.claim_controller import router as claim_router
from app.controllers.audit_controller import router as audit_router

__all__ = [
    "auth_router",
    "claim_router",
    "audit_router",
]
