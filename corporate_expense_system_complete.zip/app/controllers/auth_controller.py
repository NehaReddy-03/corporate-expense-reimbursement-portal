"""
Authentication Controller
"""
from typing import List
from fastapi import APIRouter, Depends, status
from app.models.schemas import UserLoginRequest, UserRegisterRequest, TokenResponse, UserResponse
from app.services.auth_service import AuthService
from app.middleware.auth_middleware import get_current_user

router = APIRouter(prefix="/api/auth", tags=["Authentication"])

@router.post("/register", response_model=UserResponse, status_code=status.HTTP_201_CREATED, summary="Register New Enterprise User / Employee")
def register(user_in: UserRegisterRequest):
    """
    Register a new corporate user (EMPLOYEE, MANAGER, or FINANCE).
    Enforces password hashing and email uniqueness.
    """
    return AuthService.register_user(
        name=user_in.name,
        email=user_in.email,
        password=user_in.password,
        role=user_in.role.value
    )

@router.post("/login", response_model=TokenResponse, summary="User Login")
def login(login_req: UserLoginRequest):
    """
    Authenticate an enterprise user by email and password.
    Returns a signed JWT bearer token and user role profile.
    """
    return AuthService.authenticate_user(login_req.email, login_req.password)

@router.get("/users", response_model=List[UserResponse], summary="List Test Users")
def list_users():
    """
    Returns list of configured enterprise users for demo role switching.
    """
    return AuthService.get_all_users()

@router.get("/me", response_model=UserResponse, summary="Get Current User Profile")
def get_me(current_user: dict = Depends(get_current_user)):
    """
    Returns the currently authenticated user's profile and RBAC role.
    """
    return current_user
