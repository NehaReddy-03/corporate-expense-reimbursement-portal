"""
Expense Claim Controller
HTTP routing and validation for expense submission, workflow transitions, and batch actions.
"""
from typing import List, Optional
import io
import csv
from fastapi import APIRouter, Depends, Query, Path
from fastapi.responses import Response
from app.models.schemas import (
    ClaimCreateRequest,
    ClaimActionRequest,
    ClaimResponse,
    BatchSettleResponse,
    AuditLogResponse,
    MetricsResponse,
)
from app.services.claim_service import ClaimService
from app.services.audit_service import AuditService
from app.middleware.auth_middleware import get_current_user, require_roles

router = APIRouter(prefix="/api/claims", tags=["Expense Claims"])

@router.post("", response_model=ClaimResponse, summary="Submit New Expense Claim")
def create_claim(
    claim_in: ClaimCreateRequest,
    current_user: dict = Depends(require_roles("EMPLOYEE"))
):
    """
    Submits a new expense claim.
    - Role required: EMPLOYEE
    - Runs Duplicate Detection (flags 48h identical category + amount)
    - Records immutable audit trail
    """
    return ClaimService.create_claim(current_user, claim_in)

@router.get("", response_model=List[ClaimResponse], summary="List Expense Claims")
def list_claims(
    status: Optional[str] = Query(None, description="Optional status filter: PENDING, APPROVED, REJECTED, SETTLED"),
    scope: Optional[str] = Query(None, description="Optional scope: 'my' for user's personal vouchers, 'team' or None for role-based"),
    current_user: dict = Depends(get_current_user)
):
    """
    Retrieves expense claims based on RBAC:
    - scope='my' returns the active user's own claims.
    - EMPLOYEE: Returns only their own claims.
    - MANAGER & FINANCE: Returns all enterprise claims by default.
    """
    user_override = current_user["id"] if scope == "my" else None
    return ClaimService.list_claims_for_user(current_user, status_filter=status, user_id_override=user_override)

@router.get("/metrics", response_model=MetricsResponse, summary="Get Dashboard Metrics")
def get_metrics(
    scope: Optional[str] = Query(None, description="Optional scope: 'my' for user's personal metrics"),
    current_user: dict = Depends(get_current_user)
):
    """
    Retrieves summary counts and monetary amounts for dashboard KPI cards.
    """
    user_override = current_user["id"] if (scope == "my" or current_user["role"] == "EMPLOYEE") else None
    data = ClaimService.get_dashboard_metrics(current_user, user_id_override=user_override)
    return {
        "total_claims": data.get("total_count", 0),
        "total_amount": float(data.get("total_amount", 0.0)),
        "pending_count": data.get("pending_count", 0),
        "pending_amount": float(data.get("pending_amount", 0.0)),
        "approved_count": data.get("approved_count", 0),
        "approved_amount": float(data.get("approved_amount", 0.0)),
        "settled_count": data.get("settled_count", 0),
        "settled_amount": float(data.get("settled_amount", 0.0)),
        "rejected_count": data.get("rejected_count", 0),
        "rejected_amount": float(data.get("rejected_amount", 0.0)),
    }

@router.get("/{claim_id}", response_model=ClaimResponse, summary="Get Single Claim")
def get_claim(
    claim_id: int = Path(..., gt=0),
    current_user: dict = Depends(get_current_user)
):
    """
    Retrieves details of a specific claim with RBAC verification.
    """
    return ClaimService.get_claim_details(claim_id, current_user)

@router.post("/{claim_id}/approve", response_model=ClaimResponse, summary="Approve Claim")
def approve_claim(
    claim_id: int = Path(..., gt=0),
    action_in: Optional[ClaimActionRequest] = None,
    current_user: dict = Depends(require_roles("MANAGER", "FINANCE"))
):
    """
    Approves a PENDING expense claim.
    - Roles allowed: MANAGER, FINANCE
    - Enforces threshold rule: MANAGER cannot approve claims > ₹10,000 (must be FINANCE).
    - Transitions status to APPROVED and writes immutable audit entry.
    """
    notes = action_in.notes if action_in else None
    return ClaimService.approve_claim(claim_id, current_user, notes=notes)

@router.post("/{claim_id}/reject", response_model=ClaimResponse, summary="Reject Claim")
def reject_claim(
    action_in: ClaimActionRequest,
    claim_id: int = Path(..., gt=0),
    current_user: dict = Depends(require_roles("MANAGER", "FINANCE"))
):
    """
    Rejects a PENDING expense claim.
    - Roles allowed: MANAGER, FINANCE
    - Enforces business rule: Notes/comment explaining rejection reason is MANDATORY.
    - Transitions status to REJECTED and writes immutable audit entry.
    """
    return ClaimService.reject_claim(claim_id, current_user, notes=action_in.notes)

@router.post("/{claim_id}/settle", response_model=ClaimResponse, summary="Settle Single Approved Claim")
def settle_claim(
    claim_id: int = Path(..., gt=0),
    action_in: Optional[ClaimActionRequest] = None,
    current_user: dict = Depends(require_roles("FINANCE"))
):
    """
    Settles an APPROVED expense claim for reimbursement disbursement.
    - Role allowed: FINANCE only
    - Validates state machine: claim must be in APPROVED status.
    - Transitions status to SETTLED and records audit log.
    """
    notes = action_in.notes if action_in else None
    return ClaimService.settle_single_claim(claim_id, current_user, notes=notes)

@router.post("/batch-settle", response_model=BatchSettleResponse, summary="Batch Settle All Approved Claims")
def batch_settle(current_user: dict = Depends(require_roles("FINANCE"))):
    """
    Performs one-click batch settlement for ALL claims currently in APPROVED state.
    - Role allowed: FINANCE only
    - Atomically updates status to SETTLED
    - Creates immutable audit log entries for all processed claims.
    """
    return ClaimService.batch_settle_approved(current_user)

@router.get("/{claim_id}/audit-logs", response_model=List[AuditLogResponse], summary="Get Claim Audit Trail")
def get_claim_audit_logs(
    claim_id: int = Path(..., gt=0),
    current_user: dict = Depends(get_current_user)
):
    """
    Returns full chronological audit log history for a specific claim.
    """
    return AuditService.get_claim_audit_logs(claim_id, current_user)

@router.post("/{claim_id}/cancel", response_model=ClaimResponse, summary="Cancel/Withdraw Pending Claim")
def cancel_claim(
    claim_id: int = Path(..., gt=0),
    action_in: Optional[ClaimActionRequest] = None,
    current_user: dict = Depends(get_current_user)
):
    """
    Allows a submitter to cancel/withdraw their own PENDING claim.
    """
    notes = action_in.notes if action_in else None
    return ClaimService.cancel_claim(claim_id, current_user, notes=notes)

@router.get("/export/csv", summary="Export Expense Claims to CSV")
def export_claims_csv(
    status: Optional[str] = Query(None),
    current_user: dict = Depends(get_current_user)
):
    """
    Exports expense claims to a clean CSV spreadsheet with UTF-8 BOM for Excel.
    """
    claims = ClaimService.list_claims_for_user(current_user, status_filter=status)
    output = io.StringIO()
    output.write('\ufeff')  # UTF-8 BOM for Microsoft Excel
    writer = csv.writer(output)
    writer.writerow(["Claim ID", "Submitter", "Email", "Role", "Category", "Expense Date", "Amount (INR)", "Status", "Description", "Submitted At"])
    for c in claims:
        writer.writerow([
            c["id"],
            c.get("user_name", ""),
            c.get("user_email", ""),
            c.get("user_role", ""),
            c.get("category", ""),
            c.get("expense_date", ""),
            f"{c.get('amount', 0.0):.2f}",
            c.get("status", ""),
            c.get("description", ""),
            c.get("created_at", "")
        ])
    csv_bytes = output.getvalue().encode("utf-8")
    return Response(
        content=csv_bytes,
        media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": "attachment; filename=corporate_expense_report.csv"}
    )

