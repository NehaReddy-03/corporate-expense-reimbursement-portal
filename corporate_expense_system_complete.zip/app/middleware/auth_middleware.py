"""
Authentication & Role-Based Access Control (RBAC) Middleware
Supports secure signed tokens as well as demo-friendly X-User-Id switching.
"""
import hmac
import hashlib
import base64
import json
import time
from typing import Optional, Callable
from fastapi import Header, HTTPException, status, Depends
from app.config import SECRET_KEY, ACCESS_TOKEN_EXPIRE_MINUTES
from app.repositories.user_repository import UserRepository

def create_access_token(user_id: int, email: str, role: str) -> str:
    """Creates a base64url signed JWT-compatible token using HMAC-SHA256."""
    header = {"alg": "HS256", "typ": "JWT"}
    payload = {
        "sub": user_id,
        "email": email,
        "role": role,
        "exp": int(time.time()) + (ACCESS_TOKEN_EXPIRE_MINUTES * 60)
    }
    
    def b64_encode(data: dict) -> str:
        dumped = json.dumps(data, separators=(',', ':')).encode('utf-8')
        return base64.urlsafe_b64encode(dumped).decode('utf-8').rstrip('=')

    header_b64 = b64_encode(header)
    payload_b64 = b64_encode(payload)
    message = f"{header_b64}.{payload_b64}".encode('utf-8')
    signature = hmac.new(SECRET_KEY.encode('utf-8'), message, hashlib.sha256).digest()
    sig_b64 = base64.urlsafe_b64encode(signature).decode('utf-8').rstrip('=')
    return f"{header_b64}.{payload_b64}.{sig_b64}"

def verify_token(token: str) -> Optional[dict]:
    """Verifies HMAC signature and expiration."""
    try:
        parts = token.split('.')
        if len(parts) != 3:
            return None
        header_b64, payload_b64, sig_b64 = parts
        message = f"{header_b64}.{payload_b64}".encode('utf-8')
        expected_sig = hmac.new(SECRET_KEY.encode('utf-8'), message, hashlib.sha256).digest()
        actual_sig = base64.urlsafe_b64decode(sig_b64 + '=' * (-len(sig_b64) % 4))
        
        if not hmac.compare_digest(expected_sig, actual_sig):
            return None

        # Check expiration
        payload_bytes = base64.urlsafe_b64decode(payload_b64 + '=' * (-len(payload_b64) % 4))
        payload = json.loads(payload_bytes.decode('utf-8'))
        if payload.get("exp", 0) < time.time():
            return None
        return payload
    except Exception:
        return None

def get_current_user(
    authorization: Optional[str] = Header(None),
    x_user_id: Optional[str] = Header(None)
) -> dict:
    """
    Extracts the authenticated user from:
    1. Authorization: Bearer <token>
    2. Or X-User-Id header (for instant zero-latency role-switching in the UI)
    """
    user = None

    # Priority 1: Bearer token
    if authorization and authorization.lower().startswith("bearer "):
        token = authorization[7:].strip()
        payload = verify_token(token)
        if payload and "sub" in payload:
            user = UserRepository.get_by_id(int(payload["sub"]))

    # Priority 2: X-User-Id header (for UI demo role switcher)
    if not user and x_user_id:
        try:
            uid = int(x_user_id)
            user = UserRepository.get_by_id(uid)
        except ValueError:
            pass

    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication required. Please provide a valid Bearer token or User Session.",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return user

def require_roles(*allowed_roles: str) -> Callable:
    """
    RBAC dependency factory.
    Enforces that the authenticated user possesses one of the allowed roles.
    """
    def role_checker(current_user: dict = Depends(get_current_user)) -> dict:
        user_role = current_user.get("role")
        if user_role not in allowed_roles:
            roles_str = ", ".join(allowed_roles)
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Access Denied. Role '{user_role}' is not authorized. Required: [{roles_str}]"
            )
        return current_user
    return role_checker
