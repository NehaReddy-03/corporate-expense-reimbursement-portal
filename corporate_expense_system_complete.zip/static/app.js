/**
 * Corporate Expense Claim and Reimbursement System
 * Frontend Single Page Application Logic - v2.7.0
 */

// Application State
let enterpriseUsers = [];
let currentUser = {
  id: 1,
  name: "Alice Jenkins",
  email: "employee@enterprise.local",
  role: "EMPLOYEE"
};

let currentFilter = "ALL";
let selectedCategory = "ALL";
let currentScope = "my"; // "my" for personal vouchers, "team" for department queue
let searchQuery = "";
let claimsData = [];
let pendingRejectClaimId = null;
let attachedReceiptFile = null;

const MONTHLY_BUDGET = 500000.0; // ₹5,00,000 monthly allowance

/**
 * Universal App Initialization
 * Executes immediately whether DOMContentLoaded has already fired or is pending.
 */
function initializeApp() {
  // 1. Set default expense date to today
  const today = new Date().toISOString().split("T")[0];
  const dateInput = document.getElementById("claimDate");
  if (dateInput) dateInput.value = today;

  // 2. Setup user switcher change listener
  const userSwitcher = document.getElementById("userSwitcher");
  if (userSwitcher) {
    userSwitcher.addEventListener("change", (e) => {
      switchUser(parseInt(e.target.value, 10));
    });
  }

  // 3. Load enterprise users and initial dataset
  fetchAndPopulateUsers().finally(() => {
    syncRoleUI();
    loadDashboardData();
  });
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", initializeApp);
} else {
  initializeApp();
}

/**
 * Fetch all enterprise users from API and populate the User Switcher
 */
async function fetchAndPopulateUsers() {
  try {
    const res = await fetch("/api/auth/users");
    if (res.ok) {
      enterpriseUsers = await res.json();
      const switcher = document.getElementById("userSwitcher");
      if (switcher && enterpriseUsers.length > 0) {
        switcher.innerHTML = enterpriseUsers.map(u => `
          <option value="${u.id}">${escapeHtml(u.name)} (${u.role})</option>
        `).join("");
        
        // Preserve current user or set first
        const found = enterpriseUsers.find(u => u.id === currentUser.id);
        if (found) {
          currentUser = found;
          switcher.value = found.id.toString();
        } else {
          currentUser = enterpriseUsers[0];
          switcher.value = currentUser.id.toString();
        }
      }
    }
  } catch (err) {
    console.error("Could not fetch user roster:", err);
  }
}

/**
 * Switch active session user
 */
function switchUser(userId) {
  const user = enterpriseUsers.find(u => u.id === userId);
  if (user) {
    currentUser = user;
    // Default to "my" so every user immediately sees their own unique set of claims
    currentScope = "my";
    syncRoleUI();
    loadDashboardData();
    showToast(`Switched active profile to ${user.name} (${user.role})`, "info");
  }
}

/**
 * Switch View Scope: "my" (personal vouchers) vs "team" (department queue)
 */
function setScope(scope) {
  currentScope = scope;
  const btnMy = document.getElementById("btnScopeMy");
  const btnTeam = document.getElementById("btnScopeTeam");

  if (btnMy && btnTeam) {
    if (scope === "my") {
      btnMy.className = "px-2.5 py-1 rounded-lg text-[11px] font-bold bg-white text-slate-900 shadow-xs transition";
      btnTeam.className = "px-2.5 py-1 rounded-lg text-[11px] font-semibold text-slate-500 hover:text-slate-800 transition";
    } else {
      btnMy.className = "px-2.5 py-1 rounded-lg text-[11px] font-semibold text-slate-500 hover:text-slate-800 transition";
      btnTeam.className = "px-2.5 py-1 rounded-lg text-[11px] font-bold bg-white text-slate-900 shadow-xs transition";
    }
  }

  loadDashboardData();
}

/**
 * Synchronize UI controls and permissions based on active role
 */
function syncRoleUI() {
  const rolePill = document.getElementById("rolePill");
  const btnSubmit = document.getElementById("btnOpenSubmitModal");
  const btnBatch = document.getElementById("btnBatchSettle");
  const auditTab = document.getElementById("auditLogTabBtn");
  const scopeContainer = document.getElementById("scopeToggleContainer");

  if (rolePill) {
    rolePill.textContent = currentUser.role;
    rolePill.className = "text-[11px] font-bold px-3 py-1 rounded-full uppercase tracking-wider shadow-xs";

    if (currentUser.role === "EMPLOYEE") {
      rolePill.classList.add("bg-blue-50", "text-blue-700", "border", "border-blue-200");
    } else if (currentUser.role === "MANAGER") {
      rolePill.classList.add("bg-amber-50", "text-amber-800", "border", "border-amber-200");
    } else if (currentUser.role === "FINANCE") {
      rolePill.classList.add("bg-indigo-50", "text-indigo-800", "border", "border-indigo-200");
    }
  }

  // Feature visibility per role
  if (currentUser.role === "EMPLOYEE") {
    if (btnSubmit) btnSubmit.classList.remove("hidden");
    if (btnBatch) btnBatch.classList.add("hidden");
    if (auditTab) auditTab.classList.add("hidden");
    if (scopeContainer) scopeContainer.classList.add("hidden");
  } else if (currentUser.role === "MANAGER") {
    if (btnSubmit) btnSubmit.classList.remove("hidden");
    if (btnBatch) btnBatch.classList.add("hidden");
    if (auditTab) auditTab.classList.remove("hidden");
    if (scopeContainer) scopeContainer.classList.remove("hidden");
  } else if (currentUser.role === "FINANCE") {
    if (btnSubmit) btnSubmit.classList.remove("hidden");
    if (btnBatch) btnBatch.classList.remove("hidden");
    if (auditTab) auditTab.classList.remove("hidden");
    if (scopeContainer) scopeContainer.classList.remove("hidden");
  }
}

/**
 * Fetch claims and metrics from backend
 */
async function loadDashboardData() {
  try {
    const headers = { "X-User-Id": currentUser.id.toString() };

    // 1. Fetch KPI metrics with current scope
    let metricsUrl = `/api/claims/metrics?scope=${encodeURIComponent(currentScope)}`;
    const metricsRes = await fetch(metricsUrl, { headers });
    if (metricsRes.ok) {
      const m = await metricsRes.json();
      updateKPICards(m);
    }

    // 2. Fetch claims with current status and scope
    let url = `/api/claims?scope=${encodeURIComponent(currentScope)}`;
    if (currentFilter !== "ALL" && currentFilter !== "AUDIT") {
      url += `&status=${encodeURIComponent(currentFilter)}`;
    }

    const claimsRes = await fetch(url, { headers });
    if (claimsRes.ok) {
      claimsData = await claimsRes.json();
      renderClaimsTable();
      updateSpendAnalytics(claimsData);
    } else {
      renderErrorState("Failed to retrieve claims data.");
    }
  } catch (err) {
    console.error("Error loading dashboard data:", err);
    renderErrorState("Could not connect to server. Retrying...");
  }
}

/**
 * Update Top 5 KPI Cards (Total, Pending, Approved, Settled, Rejected)
 */
function updateKPICards(m) {
  const setVal = (id, text) => {
    const el = document.getElementById(id);
    if (el) el.textContent = text;
  };

  setVal("kpiTotalCount", m.total_claims ?? 0);
  setVal("kpiTotalAmount", formatINR(m.total_amount ?? 0));

  setVal("kpiPendingCount", m.pending_count ?? 0);
  setVal("kpiPendingAmount", formatINR(m.pending_amount ?? 0));

  setVal("kpiApprovedCount", m.approved_count ?? 0);
  setVal("kpiApprovedAmount", formatINR(m.approved_amount ?? 0));

  setVal("kpiSettledCount", m.settled_count ?? 0);
  setVal("kpiSettledAmount", formatINR(m.settled_amount ?? 0));

  setVal("kpiRejectedCount", m.rejected_count ?? 0);
  setVal("kpiRejectedAmount", formatINR(m.rejected_amount ?? 0));

  // Batch modal stats
  setVal("batchApprovedCount", m.approved_count ?? 0);
  setVal("batchTotalAmount", `Total Payout: ${formatINR(m.approved_amount ?? 0)}`);
}

/**
 * Calculate & Update Spend Analytics and Budget Bar
 */
function updateSpendAnalytics(claims) {
  let catTotals = { TRAVEL: 0, MEALS: 0, EQUIPMENT: 0, OTHER: 0 };
  let grandTotal = 0;

  if (Array.isArray(claims)) {
    claims.forEach(c => {
      const amt = parseFloat(c.amount) || 0;
      grandTotal += amt;
      const cat = (c.category || "OTHER").toUpperCase();
      if (catTotals[cat] !== undefined) {
        catTotals[cat] += amt;
      } else {
        catTotals.OTHER += amt;
      }
    });
  }

  const setEl = (id, val) => {
    const el = document.getElementById(id);
    if (el) el.textContent = formatINR(val);
  };

  setEl("catTravelVal", catTotals.TRAVEL);
  setEl("catMealsVal", catTotals.MEALS);
  setEl("catEquipVal", catTotals.EQUIPMENT);
  setEl("catOtherVal", catTotals.OTHER);

  // Budget progress
  const spentPct = Math.min(100, (grandTotal / MONTHLY_BUDGET) * 100);
  const spentTextEl = document.getElementById("budgetSpentText");
  const spentPctEl = document.getElementById("budgetPctText");

  if (spentTextEl) spentTextEl.textContent = formatINR(grandTotal);
  if (spentPctEl) spentPctEl.textContent = `${spentPct.toFixed(1)}%`;

  // Segment widths
  const getWidth = (amt) => grandTotal > 0 ? `${((amt / grandTotal) * 100).toFixed(1)}%` : "0%";
  const barT = document.getElementById("barTravel");
  const barM = document.getElementById("barMeals");
  const barE = document.getElementById("barEquip");
  const barO = document.getElementById("barOther");

  if (barT) barT.style.width = getWidth(catTotals.TRAVEL);
  if (barM) barM.style.width = getWidth(catTotals.MEALS);
  if (barE) barE.style.width = getWidth(catTotals.EQUIPMENT);
  if (barO) barO.style.width = getWidth(catTotals.OTHER);
}

/**
 * Filter claims based on Search query and Category
 */
function getFilteredClaims() {
  if (!Array.isArray(claimsData)) return [];

  return claimsData.filter(c => {
    // Category filter
    if (selectedCategory !== "ALL" && (c.category || "").toUpperCase() !== selectedCategory) {
      return false;
    }
    // Search query filter
    if (searchQuery.trim() !== "") {
      const q = searchQuery.toLowerCase();
      const matchId = (c.id || "").toString().includes(q);
      const matchName = (c.user_name || "").toLowerCase().includes(q);
      const matchDesc = (c.description || "").toLowerCase().includes(q);
      const matchCat = (c.category || "").toLowerCase().includes(q);
      if (!matchId && !matchName && !matchDesc && !matchCat) return false;
    }
    return true;
  });
}

/**
 * Render the Claims Table
 */
function renderClaimsTable() {
  const tbody = document.getElementById("claimsTableBody");
  const recordCount = document.getElementById("recordCount");
  if (!tbody) return;

  const filtered = getFilteredClaims();

  if (recordCount) {
    recordCount.textContent = `${filtered.length} Record${filtered.length === 1 ? '' : 's'}`;
  }

  if (filtered.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="9" class="text-center py-12 text-slate-400">
          <div class="w-12 h-12 rounded-2xl bg-slate-100 text-slate-400 mx-auto flex items-center justify-center mb-3">
            <i class="fa-regular fa-folder-open text-xl"></i>
          </div>
          <p class="font-bold text-slate-700 text-sm">No Expense Claims Found</p>
          <p class="text-xs text-slate-400 mt-0.5">There are no records matching your active filters or search.</p>
        </td>
      </tr>
    `;
    return;
  }

  tbody.innerHTML = filtered.map(c => {
    const isOwner = c.user_id === currentUser.id;
    const isPending = c.status === "PENDING";
    const isApproved = c.status === "APPROVED";
    const amountVal = parseFloat(c.amount) || 0;
    const isOver10k = amountVal > 10000;
    const isDuplicate = Boolean(c.is_duplicate_warning || c.is_duplicate);

    // Category styling
    let catIcon = "fa-receipt";
    let catClass = "bg-slate-100 text-slate-700";
    if (c.category === "TRAVEL") {
      catIcon = "fa-plane-departure";
      catClass = "bg-blue-50 text-blue-700 border border-blue-200";
    } else if (c.category === "MEALS") {
      catIcon = "fa-utensils";
      catClass = "bg-amber-50 text-amber-700 border border-amber-200";
    } else if (c.category === "EQUIPMENT") {
      catIcon = "fa-laptop";
      catClass = "bg-purple-50 text-purple-700 border border-purple-200";
    }

    // Status badge
    let statusClass = "bg-amber-50 text-amber-800 border border-amber-200";
    let statusDot = "bg-amber-500";
    if (c.status === "APPROVED") {
      statusClass = "bg-emerald-50 text-emerald-800 border border-emerald-200";
      statusDot = "bg-emerald-500";
    } else if (c.status === "SETTLED") {
      statusClass = "bg-blue-50 text-blue-800 border border-blue-200";
      statusDot = "bg-blue-500";
    } else if (c.status === "REJECTED") {
      statusClass = "bg-rose-50 text-rose-800 border border-rose-200";
      statusDot = "bg-rose-500";
    }

    // Action buttons based on Role & State
    let actionButtons = "";

    // Manager Actions (Approve / Reject)
    if (currentUser.role === "MANAGER") {
      if (isPending) {
        if (isOver10k) {
          actionButtons += `
            <button disabled title="Amount exceeds ₹10,000 ceiling. Requires Finance Officer approval."
              class="px-2.5 py-1 text-[11px] font-bold bg-slate-100 text-slate-400 border border-slate-200 rounded-lg cursor-not-allowed">
              <i class="fa-solid fa-lock text-[10px] mr-1"></i> Needs Finance
            </button>
            <button onclick="openRejectModal(${c.id})" class="px-2.5 py-1 text-[11px] font-bold bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-lg transition">
              Reject
            </button>
          `;
        } else {
          actionButtons += `
            <button onclick="approveClaim(${c.id})" class="px-2.5 py-1 text-[11px] font-bold bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg shadow-xs transition">
              <i class="fa-solid fa-check mr-1 text-[10px]"></i> Approve
            </button>
            <button onclick="openRejectModal(${c.id})" class="px-2.5 py-1 text-[11px] font-bold bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-lg transition">
              Reject
            </button>
          `;
        }
      }
    }

    // Finance Actions (Authorize / Settle)
    if (currentUser.role === "FINANCE") {
      if (isPending) {
        actionButtons += `
          <button onclick="approveClaim(${c.id})" class="px-2.5 py-1 text-[11px] font-bold bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg shadow-xs transition" title="Finance High-Value Authorization">
            <i class="fa-solid fa-check mr-1 text-[10px]"></i> Authorize
          </button>
          <button onclick="openRejectModal(${c.id})" class="px-2.5 py-1 text-[11px] font-bold bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-lg transition">
            Reject
          </button>
        `;
      } else if (isApproved) {
        actionButtons += `
          <button onclick="settleClaim(${c.id})" class="px-2.5 py-1 text-[11px] font-bold bg-blue-600 hover:bg-blue-700 text-white rounded-lg shadow-xs transition">
            <i class="fa-solid fa-money-bill-transfer mr-1 text-[10px]"></i> Settle
          </button>
        `;
      }
    }

    // Submitter Action: Withdraw/Cancel pending claim
    if (isOwner && isPending) {
      actionButtons += `
        <button onclick="cancelPendingClaim(${c.id})" title="Withdraw this pending claim" class="px-2.5 py-1 text-[11px] font-semibold text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-lg border border-slate-200 transition">
          <i class="fa-solid fa-trash-can mr-1 text-[10px]"></i> Cancel
        </button>
      `;
    }

    // Audit Timeline Button (Always visible)
    actionButtons += `
      <button onclick="openAuditModal(${c.id})" title="View Lifecycle Audit Trail" class="p-1.5 text-slate-500 hover:text-blue-700 hover:bg-slate-100 rounded-lg text-xs transition">
        <i class="fa-solid fa-clock-rotate-left"></i>
      </button>
    `;

    return `
      <tr class="hover:bg-slate-50/80 transition">
        <!-- Claim ID -->
        <td class="py-3 px-4 font-mono font-bold text-slate-900">
          #${c.id}
        </td>

        <!-- Submitter -->
        <td class="py-3 px-4">
          <p class="font-bold text-slate-800 text-xs">${escapeHtml(c.user_name || 'Corporate Staff')}</p>
          <p class="text-[10px] text-slate-400 font-mono">${escapeHtml(c.user_email || '')}</p>
        </td>

        <!-- Category -->
        <td class="py-3 px-4">
          <span class="inline-flex items-center space-x-1.5 px-2 py-0.5 rounded-md text-[11px] font-semibold ${catClass}">
            <i class="fa-solid ${catIcon} text-[10px]"></i>
            <span>${c.category}</span>
          </span>
        </td>

        <!-- Expense Date -->
        <td class="py-3 px-4 font-mono text-[11px] text-slate-600">
          ${c.expense_date}
        </td>

        <!-- Description -->
        <td class="py-3 px-4 max-w-[220px]">
          <p class="truncate text-slate-700 text-xs" title="${escapeHtml(c.description)}">${escapeHtml(c.description)}</p>
          ${isDuplicate ? `
            <span class="inline-flex items-center text-[10px] font-bold text-amber-700 bg-amber-50 border border-amber-200 px-1.5 py-0.5 rounded mt-1">
              <i class="fa-solid fa-triangle-exclamation mr-1 text-amber-500"></i> Duplicate Match
            </span>
          ` : ''}
        </td>

        <!-- Digital Receipt Button -->
        <td class="py-3 px-4">
          <button onclick="viewReceipt(${c.id})" class="inline-flex items-center space-x-1 text-[11px] font-bold text-blue-600 hover:text-blue-800 bg-blue-50/60 hover:bg-blue-100/80 border border-blue-200/60 px-2 py-1 rounded-lg transition">
            <i class="fa-regular fa-file-lines text-xs"></i>
            <span>View Invoice</span>
          </button>
        </td>

        <!-- Amount -->
        <td class="py-3 px-4 font-mono font-bold text-slate-900 text-xs">
          ${formatINR(amountVal)}
        </td>

        <!-- Status -->
        <td class="py-3 px-4 text-center">
          <span class="inline-flex items-center space-x-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold uppercase tracking-wider ${statusClass}">
            <span class="w-1.5 h-1.5 rounded-full ${statusDot}"></span>
            <span>${c.status}</span>
          </span>
        </td>

        <!-- Actions -->
        <td class="py-3 px-4 text-right">
          <div class="flex items-center justify-end space-x-1.5">
            ${actionButtons}
          </div>
        </td>
      </tr>
    `;
  }).join("");
}

function renderErrorState(msg) {
  const tbody = document.getElementById("claimsTableBody");
  if (!tbody) return;
  tbody.innerHTML = `
    <tr>
      <td colspan="9" class="text-center py-8 text-rose-500">
        <i class="fa-solid fa-triangle-exclamation text-xl mb-1"></i>
        <p class="font-bold text-xs">${escapeHtml(msg)}</p>
      </td>
    </tr>
  `;
}

/**
 * Handle Search Input
 */
function handleSearch(e) {
  searchQuery = e.target.value;
  renderClaimsTable();
}

/**
 * Handle Category Filter
 */
function handleCategoryFilter(e) {
  selectedCategory = e.target.value;
  renderClaimsTable();
}

/**
 * Filter Tabs Controller
 */
function setFilter(status) {
  currentFilter = status;

  // Update tab active classes
  document.querySelectorAll(".filter-tab").forEach(tab => {
    if (tab.dataset.filter === status) {
      tab.className = "filter-tab active px-3.5 py-1.5 rounded-xl text-xs font-bold bg-slate-900 text-white shadow-xs transition";
    } else {
      tab.className = "filter-tab px-3.5 py-1.5 rounded-xl text-xs font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition";
    }
  });

  const claimsView = document.getElementById("claimsView");
  const auditView = document.getElementById("auditLedgerView");
  if (claimsView) claimsView.classList.remove("hidden");
  if (auditView) auditView.classList.add("hidden");

  loadDashboardData();
}

/**
 * Switch to Global Audit Ledger Tab
 */
async function switchToAuditTab() {
  currentFilter = "AUDIT";

  document.querySelectorAll(".filter-tab").forEach(tab => {
    if (tab.dataset.filter === "AUDIT") {
      tab.className = "filter-tab active px-3.5 py-1.5 rounded-xl text-xs font-bold bg-blue-700 text-white shadow-xs transition";
    } else {
      tab.className = "filter-tab px-3.5 py-1.5 rounded-xl text-xs font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition";
    }
  });

  const claimsView = document.getElementById("claimsView");
  const auditView = document.getElementById("auditLedgerView");
  if (claimsView) claimsView.classList.add("hidden");
  if (auditView) auditView.classList.remove("hidden");

  await loadAuditLedger();
}

function switchToClaimsTab() {
  setFilter("ALL");
}

/**
 * Load Global Audit Ledger
 */
async function loadAuditLedger() {
  const tbody = document.getElementById("auditTableBody");
  if (!tbody) return;

  tbody.innerHTML = `
    <tr>
      <td colspan="7" class="text-center py-10 text-slate-400">
        <i class="fa-solid fa-spinner fa-spin text-xl text-blue-600 mb-2"></i>
        <p>Loading audit ledger...</p>
      </td>
    </tr>
  `;

  try {
    const res = await fetch("/api/audit-logs", {
      headers: { "X-User-Id": currentUser.id.toString() }
    });

    if (res.ok) {
      const logs = await res.json();
      if (logs.length === 0) {
        tbody.innerHTML = `<tr><td colspan="7" class="text-center py-8 text-slate-400">No audit records logged yet.</td></tr>`;
        return;
      }

      tbody.innerHTML = logs.map(l => {
        let actionClass = "bg-slate-100 text-slate-800";
        if (l.action.includes("APPROVED")) actionClass = "bg-emerald-50 text-emerald-800 border border-emerald-200";
        if (l.action.includes("REJECTED") || l.action.includes("CANCEL")) actionClass = "bg-rose-50 text-rose-800 border border-rose-200";
        if (l.action.includes("SETTLE")) actionClass = "bg-blue-50 text-blue-800 border border-blue-200";

        return `
          <tr class="hover:bg-slate-50/80 transition">
            <td class="py-3 px-4 font-bold text-slate-900">#LOG-${l.id}</td>
            <td class="py-3 px-4 text-slate-500 text-[11px]">${formatDate(l.timestamp)}</td>
            <td class="py-3 px-4 font-bold text-blue-600">#EXP-${l.claim_id}</td>
            <td class="py-3 px-4 font-sans font-semibold text-slate-800">${escapeHtml(l.actor_name || 'System')}</td>
            <td class="py-3 px-4 text-[11px] text-slate-500">${escapeHtml(l.actor_role || '')}</td>
            <td class="py-3 px-4">
              <span class="px-2 py-0.5 rounded text-[10px] font-bold ${actionClass}">${l.action}</span>
            </td>
            <td class="py-3 px-4 font-sans text-xs text-slate-700">${escapeHtml(l.notes || 'No comments recorded')}</td>
          </tr>
        `;
      }).join("");
    }
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="7" class="text-center py-6 text-rose-600">Failed to load audit logs.</td></tr>`;
  }
}

/**
 * View Digital Receipt & Tax Invoice Modal
 */
function viewReceipt(claimId) {
  const claim = claimsData.find(c => c.id === claimId);
  if (!claim) return;

  const setVal = (id, text) => {
    const el = document.getElementById(id);
    if (el) el.textContent = text;
  };

  setVal("rcptId", `REF: #EXP-${claim.id}`);
  setVal("rcptUser", claim.user_name || "Corporate Employee");
  setVal("rcptDate", claim.expense_date);
  setVal("rcptCat", claim.category);
  setVal("rcptDesc", claim.description);
  setVal("rcptTotal", formatINR(claim.amount));

  const badge = document.getElementById("rcptBadge");
  if (badge) {
    badge.textContent = claim.status;
    badge.className = "text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider";
    if (claim.status === "APPROVED") badge.classList.add("bg-emerald-100", "text-emerald-800", "border", "border-emerald-200");
    else if (claim.status === "SETTLED") badge.classList.add("bg-blue-100", "text-blue-800", "border", "border-blue-200");
    else if (claim.status === "REJECTED") badge.classList.add("bg-rose-100", "text-rose-800", "border", "border-rose-200");
    else badge.classList.add("bg-amber-100", "text-amber-800", "border", "border-amber-200");
  }

  const modal = document.getElementById("receiptModal");
  if (modal) modal.classList.remove("hidden");
}

function closeReceiptModal() {
  const modal = document.getElementById("receiptModal");
  if (modal) modal.classList.add("hidden");
}

/**
 * Corporate Policy Guidelines Modal
 */
function openPolicyModal() {
  const modal = document.getElementById("policyModal");
  if (modal) modal.classList.remove("hidden");
}

function closePolicyModal() {
  const modal = document.getElementById("policyModal");
  if (modal) modal.classList.add("hidden");
}

/**
 * Handle Receipt File Select
 */
function handleReceiptFileSelect(e) {
  const file = e.target.files[0];
  if (file) {
    attachedReceiptFile = file;
    document.getElementById("receiptUploadPlaceholder")?.classList.add("hidden");
    const selectedDiv = document.getElementById("receiptUploadSelected");
    const nameEl = document.getElementById("receiptFileName");
    if (selectedDiv) selectedDiv.classList.remove("hidden");
    if (nameEl) nameEl.innerHTML = `<i class="fa-solid fa-file-lines mr-1.5"></i> ${escapeHtml(file.name)}`;
  }
}

function clearReceiptFile(e) {
  if (e) e.stopPropagation();
  attachedReceiptFile = null;
  const input = document.getElementById("receiptFileInput");
  if (input) input.value = "";
  document.getElementById("receiptUploadPlaceholder")?.classList.remove("hidden");
  document.getElementById("receiptUploadSelected")?.classList.add("hidden");
}

/**
 * Export Claims to CSV (Instant client-side export with UTF-8 BOM)
 */
function exportClaimsToCSV() {
  const filtered = getFilteredClaims();
  if (filtered.length === 0) {
    showToast("No claims available to export.", "warning");
    return;
  }

  let csvContent = "\ufeff"; // UTF-8 BOM for Microsoft Excel
  csvContent += "Claim ID,Submitter,Email,Category,Expense Date,Amount (INR),Status,Description,Duplicate Flag\r\n";

  filtered.forEach(c => {
    const isDup = Boolean(c.is_duplicate_warning || c.is_duplicate);
    const row = [
      c.id,
      `"${(c.user_name || '').replace(/"/g, '""')}"`,
      `"${(c.user_email || '').replace(/"/g, '""')}"`,
      `"${c.category}"`,
      `"${c.expense_date}"`,
      (parseFloat(c.amount) || 0).toFixed(2),
      `"${c.status}"`,
      `"${(c.description || '').replace(/"/g, '""')}"`,
      isDup ? "YES" : "NO"
    ];
    csvContent += row.join(",") + "\r\n";
  });

  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.setAttribute("href", url);
  link.setAttribute("download", `corporate_expense_report_${new Date().toISOString().split("T")[0]}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  showToast("Corporate expense report exported to CSV.", "success");
}

/**
 * Submit New Claim Form Handler
 */
async function handleClaimSubmit(e) {
  e.preventDefault();
  const btn = document.getElementById("btnSubmitClaim");
  if (btn) btn.disabled = true;

  const category = document.getElementById("claimCategory").value;
  const amount = parseFloat(document.getElementById("claimAmount").value);
  const expense_date = document.getElementById("claimDate").value;
  const description = document.getElementById("claimDescription").value;

  try {
    const res = await fetch("/api/claims", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-User-Id": currentUser.id.toString()
      },
      body: JSON.stringify({ category, amount, expense_date, description })
    });

    if (res.ok) {
      const claim = await res.json();
      closeSubmitModal();
      document.getElementById("claimForm")?.reset();
      clearReceiptFile();
      await loadDashboardData();

      if (claim.is_duplicate_warning || claim.is_duplicate) {
        showToast(`Claim #${claim.id} filed successfully, but flagged as a duplicate match (48h window).`, "warning");
      } else {
        showToast(`Expense claim #${claim.id} submitted successfully!`, "success");
      }
    } else {
      const err = await res.json();
      showToast(err.detail || "Error submitting claim.", "error");
    }
  } catch (err) {
    showToast("Network error submitting claim.", "error");
  } finally {
    if (btn) btn.disabled = false;
  }
}

/**
 * Cancel/Withdraw Pending Claim by Submitter
 */
async function cancelPendingClaim(claimId) {
  if (!confirm(`Are you sure you want to withdraw Claim #${claimId}? This action cannot be undone.`)) {
    return;
  }

  try {
    const res = await fetch(`/api/claims/${claimId}/cancel`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-User-Id": currentUser.id.toString()
      },
      body: JSON.stringify({ notes: "Claim withdrawn by employee." })
    });

    if (res.ok) {
      showToast(`Claim #${claimId} has been withdrawn and cancelled.`, "info");
      loadDashboardData();
    } else {
      const err = await res.json();
      showToast(err.detail || "Could not withdraw claim.", "error");
    }
  } catch (err) {
    showToast("Network error cancelling claim.", "error");
  }
}

/**
 * Approve Claim Handler
 */
async function approveClaim(claimId) {
  try {
    const res = await fetch(`/api/claims/${claimId}/approve`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-User-Id": currentUser.id.toString()
      },
      body: JSON.stringify({ notes: `Approved by ${currentUser.name} (${currentUser.role})` })
    });

    if (res.ok) {
      showToast(`Claim #${claimId} approved successfully!`, "success");
      loadDashboardData();
    } else {
      const err = await res.json();
      showToast(err.detail || "Approval rejected by server.", "error");
    }
  } catch (err) {
    showToast("Network error approving claim.", "error");
  }
}

/**
 * Reject Claim Handlers
 */
function openRejectModal(claimId) {
  pendingRejectClaimId = claimId;
  const modal = document.getElementById("rejectModal");
  const input = document.getElementById("rejectNotesInput");
  const errText = document.getElementById("rejectErrorText");
  if (input) input.value = "";
  if (errText) errText.classList.add("hidden");
  if (modal) modal.classList.remove("hidden");
}

function closeRejectModal() {
  pendingRejectClaimId = null;
  const modal = document.getElementById("rejectModal");
  if (modal) modal.classList.add("hidden");
}

async function confirmRejectClaim() {
  if (!pendingRejectClaimId) return;
  const notes = document.getElementById("rejectNotesInput").value.trim();
  const errText = document.getElementById("rejectErrorText");

  // Mandatory rejection note validation
  if (!notes) {
    if (errText) errText.classList.remove("hidden");
    return;
  }

  try {
    const res = await fetch(`/api/claims/${pendingRejectClaimId}/reject`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-User-Id": currentUser.id.toString()
      },
      body: JSON.stringify({ notes })
    });

    if (res.ok) {
      closeRejectModal();
      showToast(`Claim #${pendingRejectClaimId} was rejected and reason logged to audit trail.`, "warning");
      loadDashboardData();
    } else {
      const err = await res.json();
      showToast(err.detail || "Rejection error.", "error");
    }
  } catch (err) {
    showToast("Network error rejecting claim.", "error");
  }
}

/**
 * Settle Single Claim Handler
 */
async function settleClaim(claimId) {
  try {
    const res = await fetch(`/api/claims/${claimId}/settle`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-User-Id": currentUser.id.toString()
      },
      body: JSON.stringify({ notes: `Single disbursement executed by Finance (${currentUser.name})` })
    });

    if (res.ok) {
      showToast(`Claim #${claimId} settled and reimbursement disbursed!`, "success");
      loadDashboardData();
    } else {
      const err = await res.json();
      showToast(err.detail || "Settlement error.", "error");
    }
  } catch (err) {
    showToast("Network error settling claim.", "error");
  }
}

/**
 * Batch Settlement Handlers (Finance)
 */
function openBatchSettleModal() {
  const modal = document.getElementById("batchSettleModal");
  if (modal) modal.classList.remove("hidden");
}

function closeBatchSettleModal() {
  const modal = document.getElementById("batchSettleModal");
  if (modal) modal.classList.add("hidden");
}

async function executeBatchSettlement() {
  const btn = document.getElementById("btnConfirmBatchSettle");
  if (btn) btn.disabled = true;

  try {
    const res = await fetch("/api/claims/batch-settle", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-User-Id": currentUser.id.toString()
      }
    });

    if (res.ok) {
      const result = await res.json();
      closeBatchSettleModal();
      showToast(result.message || "Batch settlement completed successfully!", "success");
      loadDashboardData();
    } else {
      const err = await res.json();
      showToast(err.detail || "Batch settlement failed.", "error");
    }
  } catch (err) {
    showToast("Network error during batch settlement.", "error");
  } finally {
    if (btn) btn.disabled = false;
  }
}

/**
 * Audit Trail Timeline Modal
 */
async function openAuditModal(claimId) {
  const modal = document.getElementById("auditModal");
  const sub = document.getElementById("auditClaimSubtitle");
  const container = document.getElementById("auditTimelineContainer");

  if (sub) sub.textContent = `Claim #EXP-${claimId} Lifecycle History`;
  if (container) {
    container.innerHTML = `
      <div class="text-center py-6 text-slate-400">
        <i class="fa-solid fa-spinner fa-spin text-lg text-blue-600 mb-2"></i>
        <p class="text-xs">Loading immutable trail...</p>
      </div>
    `;
  }
  if (modal) modal.classList.remove("hidden");

  try {
    const res = await fetch(`/api/claims/${claimId}/audit-logs`, {
      headers: { "X-User-Id": currentUser.id.toString() }
    });

    if (res.ok) {
      const logs = await res.json();
      if (logs.length === 0) {
        container.innerHTML = `<p class="text-xs text-slate-400">No audit records found for this claim.</p>`;
        return;
      }

      container.innerHTML = logs.map(l => {
        let dotColor = "bg-blue-600 ring-blue-100";
        let icon = "fa-file-invoice";

        if (l.action.includes("APPROVED")) {
          dotColor = "bg-emerald-600 ring-emerald-100";
          icon = "fa-check";
        } else if (l.action.includes("REJECTED") || l.action.includes("CANCEL")) {
          dotColor = "bg-rose-600 ring-rose-100";
          icon = "fa-ban";
        } else if (l.action.includes("SETTLE")) {
          dotColor = "bg-indigo-600 ring-indigo-100";
          icon = "fa-building-columns";
        }

        return `
          <div class="relative pl-6">
            <span class="absolute -left-[17px] top-1 w-6 h-6 rounded-full ${dotColor} ring-4 flex items-center justify-center text-white text-[10px]">
              <i class="fa-solid ${icon}"></i>
            </span>
            <div class="bg-slate-50 border border-slate-200/80 rounded-xl p-3.5 space-y-1">
              <div class="flex justify-between items-center text-xs">
                <span class="font-bold text-slate-800 uppercase text-[11px]">${l.action}</span>
                <span class="text-[10px] text-slate-400 font-mono">${formatDate(l.timestamp)}</span>
              </div>
              <p class="text-[11px] text-slate-500 font-medium">Actor: <strong class="text-slate-700">${escapeHtml(l.actor_name || 'System')}</strong> (${escapeHtml(l.actor_role || 'STAFF')})</p>
              <p class="text-xs text-slate-700 mt-1 italic">${escapeHtml(l.notes || '')}</p>
            </div>
          </div>
        `;
      }).join("");
    }
  } catch (err) {
    if (container) container.innerHTML = `<p class="text-xs text-rose-600">Failed to load audit history.</p>`;
  }
}

function closeAuditModal() {
  const modal = document.getElementById("auditModal");
  if (modal) modal.classList.add("hidden");
}

/**
 * Register New Corporate User Modal
 */
function openRegisterModal() {
  const modal = document.getElementById("registerModal");
  if (modal) modal.classList.remove("hidden");
}

function closeRegisterModal() {
  const modal = document.getElementById("registerModal");
  if (modal) modal.classList.add("hidden");
}

async function handleRegisterSubmit(e) {
  e.preventDefault();
  const name = document.getElementById("regName").value;
  const email = document.getElementById("regEmail").value;
  const password = document.getElementById("regPassword").value;
  const role = document.getElementById("regRole").value;

  try {
    const res = await fetch("/api/auth/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, email, password, role })
    });

    if (res.ok) {
      closeRegisterModal();
      document.getElementById("registerForm")?.reset();
      showToast(`User ${name} (${role}) registered successfully!`, "success");
      await fetchAndPopulateUsers();
    } else {
      const err = await res.json();
      showToast(err.detail || "Registration failed.", "error");
    }
  } catch (err) {
    showToast("Network error during registration.", "error");
  }
}

/**
 * Submit Modal Open/Close & Validation
 */
function openSubmitModal() {
  const modal = document.getElementById("submitModal");
  if (modal) modal.classList.remove("hidden");
}

function closeSubmitModal() {
  const modal = document.getElementById("submitModal");
  if (modal) modal.classList.add("hidden");
}

function validateAmountThreshold() {
  const amountInput = document.getElementById("claimAmount");
  const warning = document.getElementById("amountWarning");
  if (!amountInput || !warning) return;

  const val = parseFloat(amountInput.value) || 0;
  if (val > 10000) {
    warning.classList.remove("hidden");
  } else {
    warning.classList.add("hidden");
  }
}

/**
 * Toast Notification System
 */
function showToast(message, type = "info") {
  const container = document.getElementById("toastContainer");
  if (!container) return;

  let bg = "bg-slate-900 border-slate-700 text-white";
  let icon = "fa-circle-info text-blue-400";

  if (type === "success") {
    bg = "bg-emerald-950 border-emerald-800 text-emerald-100";
    icon = "fa-circle-check text-emerald-400";
  } else if (type === "warning") {
    bg = "bg-amber-950 border-amber-800 text-amber-100";
    icon = "fa-triangle-exclamation text-amber-400";
  } else if (type === "error") {
    bg = "bg-rose-950 border-rose-800 text-rose-100";
    icon = "fa-circle-xmark text-rose-400";
  }

  const toast = document.createElement("div");
  toast.className = `p-3.5 rounded-xl border shadow-xl flex items-center space-x-3 text-xs font-medium transform transition-all duration-300 pointer-events-auto ${bg}`;
  toast.innerHTML = `
    <i class="fa-solid ${icon} text-base shrink-0"></i>
    <span class="flex-1">${escapeHtml(message)}</span>
    <button onclick="this.parentElement.remove()" class="text-slate-400 hover:text-white ml-2 text-sm">&times;</button>
  `;

  container.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = "0";
    setTimeout(() => toast.remove(), 300);
  }, 4500);
}

/**
 * Utility Functions
 */
function formatINR(amount) {
  const num = Number(amount) || 0;
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    minimumFractionDigits: 2
  }).format(num);
}

function formatDate(isoStr) {
  if (!isoStr) return "";
  try {
    const d = new Date(isoStr);
    return d.toLocaleString("en-IN", {
      dateStyle: "medium",
      timeStyle: "short"
    });
  } catch (e) {
    return isoStr;
  }
}

function escapeHtml(str) {
  if (!str) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}
