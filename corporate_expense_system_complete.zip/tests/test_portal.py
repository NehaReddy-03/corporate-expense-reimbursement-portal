"""
Automated Enterprise Test Suite
Verifies:
1. Seed Data Integrity & Authentication
2. Role-Based Access Control (RBAC)
3. State Machine Transitions & Invalidation Guardrails
4. Enterprise Business Rules Engine (Threshold Limit & Duplicate Detection)
5. Mandatory Comments on Rejection
6. Immutable Audit Trail Persistence
7. One-Click Batch Settlement
"""
import unittest
from datetime import date
from fastapi import HTTPException

from app.repositories.database import init_db
from seed import seed_database
from app.services.auth_service import AuthService
from app.services.claim_service import ClaimService
from app.services.audit_service import AuditService
from app.models.schemas import ClaimCreateRequest, ClaimCategory
from app.repositories.user_repository import UserRepository
from app.repositories.claim_repository import ClaimRepository

class EnterprisePortalTestCase(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # Force re-seed database before tests
        init_db()
        seed_database(force=True)

        cls.employee = UserRepository.get_by_email("employee@enterprise.local")
        cls.manager = UserRepository.get_by_email("manager@enterprise.local")
        cls.finance = UserRepository.get_by_email("finance@enterprise.local")

    def test_01_user_seed_and_auth(self):
        """Verify the 3 test users exist with password123."""
        self.assertIsNotNone(self.employee)
        self.assertEqual(self.employee["role"], "EMPLOYEE")

        self.assertIsNotNone(self.manager)
        self.assertEqual(self.manager["role"], "MANAGER")

        self.assertIsNotNone(self.finance)
        self.assertEqual(self.finance["role"], "FINANCE")

        # Test valid login
        res = AuthService.authenticate_user("employee@enterprise.local", "password123")
        self.assertIn("access_token", res)
        self.assertEqual(res["user"]["email"], "employee@enterprise.local")

        # Test invalid password raises 401
        with self.assertRaises(HTTPException) as ctx:
            AuthService.authenticate_user("employee@enterprise.local", "wrongpassword")
        self.assertEqual(ctx.exception.status_code, 401)

    def test_02_claim_submission_and_duplicate_detection(self):
        """Verify claim creation and the 48-hour duplicate detection engine."""
        req1 = ClaimCreateRequest(
            category=ClaimCategory.TRAVEL,
            amount=3200.0,
            description="Inter-city client engagement transit",
            expense_date=date.today()
        )
        claim1 = ClaimService.create_claim(self.employee, req1)
        self.assertEqual(claim1["status"], "PENDING")
        self.assertFalse(claim1["is_duplicate_warning"])

        # Immediate identical submission (same user, category, and amount)
        req2 = ClaimCreateRequest(
            category=ClaimCategory.TRAVEL,
            amount=3200.0,
            description="Duplicate submission test",
            expense_date=date.today()
        )
        claim2 = ClaimService.create_claim(self.employee, req2)
        self.assertEqual(claim2["status"], "PENDING")
        self.assertTrue(claim2["is_duplicate_warning"], "Duplicate Detection Engine should flag matching 48h submission")

        # Verify audit log recorded duplicate alert
        audit_logs = AuditService.get_claim_audit_logs(claim2["id"], self.employee)
        self.assertTrue(any("DUPLICATE ALERT" in str(l.get("notes")) for l in audit_logs))

    def test_03_manager_threshold_rule(self):
        """
        Verify Manager Threshold Rule:
        - Manager CAN approve claims <= 10,000
        - Manager CANNOT approve claims > 10,000 (raises HTTP 403)
        - Finance CAN approve claims > 10,000
        """
        # Create claim exceeding 10,000
        high_claim_req = ClaimCreateRequest(
            category=ClaimCategory.EQUIPMENT,
            amount=15000.0,
            description="Ultra-wide curved coding monitor",
            expense_date=date.today()
        )
        high_claim = ClaimService.create_claim(self.employee, high_claim_req)

        # Attempt Manager approval -> Must raise 403 Forbidden
        with self.assertRaises(HTTPException) as ctx:
            ClaimService.approve_claim(high_claim["id"], self.manager)
        self.assertEqual(ctx.exception.status_code, 403)
        self.assertIn("exceeds the Manager approval limit", ctx.exception.detail)

        # Finance approval -> Must succeed
        approved_high = ClaimService.approve_claim(high_claim["id"], self.finance, notes="Finance authorized high-value IT asset")
        self.assertEqual(approved_high["status"], "APPROVED")

    def test_04_mandatory_rejection_notes(self):
        """Verify that rejecting a claim without notes raises HTTP 422."""
        rej_req = ClaimCreateRequest(
            category=ClaimCategory.MEALS,
            amount=750.0,
            description="Coffee meeting without client receipt",
            expense_date=date.today()
        )
        claim_to_reject = ClaimService.create_claim(self.employee, rej_req)

        # Reject with empty notes -> Must raise 422
        with self.assertRaises(HTTPException) as ctx:
            ClaimService.reject_claim(claim_to_reject["id"], self.manager, notes="")
        self.assertEqual(ctx.exception.status_code, 422)

        # Reject with valid notes -> Must succeed
        rejected = ClaimService.reject_claim(claim_to_reject["id"], self.manager, notes="Missing itemized tax receipt")
        self.assertEqual(rejected["status"], "REJECTED")

        # Audit log must contain the rejection reason
        logs = AuditService.get_claim_audit_logs(claim_to_reject["id"], self.manager)
        self.assertTrue(any("Missing itemized tax receipt" in str(l.get("notes")) for l in logs))

    def test_05_claim_state_machine_guardrails(self):
        """
        State Machine validation:
        - Cannot settle a REJECTED claim (HTTP 400)
        - Cannot settle a PENDING claim (HTTP 400)
        - Cannot re-approve an already APPROVED or REJECTED claim (HTTP 400)
        """
        # 1. Test settling a REJECTED claim (Claim #4 from seeds)
        with self.assertRaises(HTTPException) as ctx:
            ClaimService.settle_single_claim(4, self.finance)
        self.assertEqual(ctx.exception.status_code, 400)
        self.assertIn("Cannot settle", ctx.exception.detail)

        # 2. Test settling a PENDING claim (Claim #1 from seeds)
        with self.assertRaises(HTTPException) as ctx:
            ClaimService.settle_single_claim(1, self.finance)
        self.assertEqual(ctx.exception.status_code, 400)
        self.assertIn("Cannot settle", ctx.exception.detail)

        # 3. Test re-approving an already APPROVED claim (Claim #2 from seeds)
        with self.assertRaises(HTTPException) as ctx:
            ClaimService.approve_claim(2, self.manager)
        self.assertEqual(ctx.exception.status_code, 400)

    def test_06_finance_batch_settlement(self):
        """
        Verify One-Click Batch Settlement:
        - Only Finance role can trigger
        - Transitions all APPROVED claims to SETTLED
        - Emits BATCH_SETTLEMENT audit logs
        """
        # Non-finance role attempting batch settle -> 403 Forbidden
        with self.assertRaises(HTTPException) as ctx:
            ClaimService.batch_settle_approved(self.manager)
        self.assertEqual(ctx.exception.status_code, 403)

        # Finance performs batch settle
        batch_res = ClaimService.batch_settle_approved(self.finance)
        self.assertGreater(batch_res["settled_count"], 0)
        self.assertGreater(batch_res["total_amount"], 0)

        # Verify all claims are now SETTLED
        for cid in batch_res["settled_claim_ids"]:
            c = ClaimRepository.get_by_id(cid)
            self.assertEqual(c["status"], "SETTLED")

            # Check audit log for BATCH_SETTLEMENT
            logs = AuditService.get_claim_audit_logs(cid, self.finance)
            self.assertTrue(any(l["action"] == "BATCH_SETTLEMENT" for l in logs))

    def test_07_immutable_audit_trail(self):
        """Verify immutable audit records cannot be tampered with."""
        all_logs = AuditService.get_enterprise_audit_logs(self.finance)
        self.assertGreater(len(all_logs), 5)

        # Verify EMPLOYEE is forbidden from inspecting all enterprise logs
        with self.assertRaises(HTTPException) as ctx:
            AuditService.get_enterprise_audit_logs(self.employee)
        self.assertEqual(ctx.exception.status_code, 403)

if __name__ == "__main__":
    unittest.main()
