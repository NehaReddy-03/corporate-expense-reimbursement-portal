import subprocess
import time
import urllib.request
import sys

python_exe = sys.executable
proc = subprocess.Popen([python_exe, "run.py"])
time.sleep(2.5)

try:
    with urllib.request.urlopen("http://127.0.0.1:8000/health") as resp:
        print("GET /health ->", resp.status, resp.read().decode())
    with urllib.request.urlopen("http://127.0.0.1:8000/api-docs") as resp:
        print("GET /api-docs ->", resp.status)
    with urllib.request.urlopen("http://127.0.0.1:8000/") as resp:
        content = resp.read().decode()
        print(f"GET / (Frontend SPA) -> {resp.status}, HTML Length: {len(content)} chars")
    with urllib.request.urlopen("http://127.0.0.1:8000/api/auth/users") as resp:
        print("GET /api/auth/users ->", resp.status, resp.read().decode())
finally:
    proc.terminate()
    proc.wait()
    print("Server cleanly stopped.")
